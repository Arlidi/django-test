from django.urls import path, include
from new.views import *


app_name = 'new'
urlpatterns = [
    path('create/', Car_Create_View.as_view()),
    path('all/', Car_list_view.as_view()),
    path('deteil/<int:pk>', Car_deteil_view.as_view())
]
