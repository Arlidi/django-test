from django.db import models
from django.contrib.auth import get_user_model
User = get_user_model()
# Create your models here.

class Car(models.Model):
    vin = models.CharField(verbose_name='Vin', unique = True, db_index=True, max_length=64)
    color = models.CharField(verbose_name='Color', max_length=64)
    brend = models.CharField(verbose_name='Brend', max_length=64)
    CART_TYPE = (
    (1, "first"),
    (2, "second"),
    (3, 'dsadas')
    )
    car_type = models.IntegerField(verbose_name='Cart_type', choices=CART_TYPE)
    user = models.ForeignKey(User, verbose_name='User', on_delete=models.CASCADE)
