from rest_framework import serializers
from new.models import Car

class Car_deteil_serializer(serializers.ModelSerializer):
    class Meta:
        model = Car
        fields = "__all__"


class Car_list_serializer(serializers.ModelSerializer):
    class Meta:
        model = Car
        fields = ('id', 'vin', 'user')
