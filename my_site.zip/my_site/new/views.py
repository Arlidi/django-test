from django.shortcuts import render
from django.http import HttpResponse
from rest_framework import generics
from new.serializers import Car_deteil_serializer, Car_list_serializer
from new.models import Car


def index(request):
    return HttpResponse("<h3> ADsadsa </h3>")
# Create your views here.

class Car_Create_View(generics.CreateAPIView):
    serializer_class = Car_deteil_serializer

class Car_list_view(generics.ListAPIView):
    serializer_class = Car_list_serializer
    queryset = Car.objects.all()

class Car_deteil_view(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = Car_deteil_serializer
    queryset = Car.objects.all()
